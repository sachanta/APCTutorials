package com.javatales.axis;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Random;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;

import com.javatales.axis.to.BinaryFileTO;
import com.javatales.axis.to.FAMEArgumentsTO;
import com.javatales.axis.to.FAMEExecutionResultsTO;
import com.javatales.axis.util.IOUtil;

/**
 * This class is responsable for invoking the FAME 
 * runtime environment.<BR>
 * This is a dummy implementation of the real Command
 * Executor.
 *
 * 
 */
public class FAMECommandExecutor {
	
	private static final String PATH = "/tmp/";
	private static final String DUMMY_RETURN_DOCS_PATH = "/tmp/dummy/";
	/**
	 * Dummy implementation.<BR>
	 * Copies the procedure, the subprocedures and the
	 * datasets into /tmp folder.
	 * @param to
	 * @return
	 */
	public String executeProcedure(FAMEArgumentsTO to) {
		
		System.err.println("Entering... execute()");
		
        Random generator = new Random();
        FAMEExecutionResultsTO results = new FAMEExecutionResultsTO();

        final String requestId =
            new Integer(generator.nextInt(1000000)).toString();

        results.setCorrelationId(requestId);
		
		persistArguments(to, requestId);
		
        System.err.println("Exiting... execute()");

        return requestId;
	}
	
	
	/**
	 * Dummy method. The real method should contact the
	 * FAME runtime environment and retrieve the results
	 * produced during a previous operation marked
	 * with the provided correlation ID.<BR>
	 * This dummy method simply reads some files from
	 * a directory and returns them.
	 * @param corrId a process correlation id
	 * @return a FAMEExecutionResultsTO object containing
	 *         the produced documents.
	 */
	public FAMEExecutionResultsTO getResults(final String corrId) {
		FAMEExecutionResultsTO to = new FAMEExecutionResultsTO();
		String[] datasets = new String[2];
		try {
			
			datasets[0] = new String(IOUtil.readFile(new File(DUMMY_RETURN_DOCS_PATH+"dataset1")));
			datasets[1] = new String(IOUtil.readFile(new File(DUMMY_RETURN_DOCS_PATH+"dataset2")));
			to.setDatasetFiles(datasets);
		} catch (IOException e) {
			e.printStackTrace();
		}	
		BinaryFileTO[] binaries = new BinaryFileTO[1];
		try {
			
			DataSource ds =
            new org.apache.soap.util.mime.ByteArrayDataSource(IOUtil.readFile(new File(DUMMY_RETURN_DOCS_PATH+"binary1")), "application/pdf");
			DataHandler d = new DataHandler(ds);
			BinaryFileTO bto = new BinaryFileTO("test_binary", d);
			binaries[0]=bto;
		} catch (IOException e) {
			e.printStackTrace();
		}
		to.setBinaryFiles(binaries);
		return to;
	}
	
	

	
	
	
	private void persistArguments(final FAMEArgumentsTO to, 
								  final String correlationId){
		
		if (to!=null) {
			
		
			// Create a directory for this correlation id
	        File f = IOUtil.createDir(PATH+correlationId);
				
	        if ((to.getMainProcedure() != null)
		                && (to.getMainProcedure().getFAME4GLCode() != null)) {
		            String FAMEInp = to.getMainProcedure().getFAME4GLCode();
		            IOUtil.writeFile(f.getPath() + "/" + to.getMainProcedure().getProcedureName()
		                + ".txt", FAMEInp);
		        
			}
	        
	        if ((to.datasets!=null)&&(to.datasets.length!=0)) {
	        	for (int i = 0; i < to.datasets.length; i++) {
					
	        		try {
						IOUtil.writeDataHandler(to.datasets[i], f.getPath()+"/"+"dataset"+i);
					} catch (Exception e) {
						
						e.printStackTrace();
					}
					
				}
	        }
		}
	}
	
	
	
}
