package com.javatales.axis;

import com.javatales.axis.to.FAMEArgumentsTO;
import com.javatales.axis.to.FAMEExecutionResultsTO;

/**
 * The interface of the FAME web service.<BR>
 * It is a good practice to code against an interface
 * instead of a concrete class. 
 */
public interface FameService {
	
	/**
	 * Execute a FAME procedure.
	 * @param argument
	 * @return a String containing a correlation id
	 */
	public String executeFameProcedure(FAMEArgumentsTO argument);
	
	/**
	 * @param correlationId
	 * @return
	 */
	public FAMEExecutionResultsTO retrieveResult(String correlationId);

}
