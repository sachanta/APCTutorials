/*
 * Created on 8-feb-2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.javatales.axis;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;

import sun.awt.image.ByteInterleavedRaster;

import com.javatales.axis.to.FAMEArgumentsTO;
import com.javatales.axis.to.FAMEExecutionResultsTO;

/**
 * @author lfiandesio
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class FameServiceImpl implements FameService {

	/* (non-Javadoc)
	 * @see com.javatales.axis.FameService#executeFameProcedure(com.javatales.axis.to.FAMEArgumentsTO)
	 */
	public String executeFameProcedure(final FAMEArgumentsTO argument) {
		FAMECommandExecutor fameExec = new FAMECommandExecutor();
		return fameExec.executeProcedure(argument);
		//null;
	}

	/* (non-Javadoc)
	 * @see com.javatales.axis.FameService#retrieveResult(java.lang.String)
	 */
	public FAMEExecutionResultsTO retrieveResult(final String correlationId) {
		FAMECommandExecutor c = new FAMECommandExecutor();
		return c.getResults(correlationId);
	}
	/*
	public void receiveFile(final byte[] file){
	
		ByteBuffer b = ByteBuffer.wrap(file);
		try {
			FileChannel fc = new FileOutputStream("c:/text.txt").getChannel();
			fc.write(b);
			fc.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) throws Exception {
		
		FameServiceImpl i = new FameServiceImpl();
		i.receiveFile("test".getBytes());	
		
	}*/

}
