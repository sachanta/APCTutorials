/*
 * Created on May 25, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.javatales.axis;

import com.javatales.axis.to.FAMEExecutionResultsTO;

import junit.framework.TestCase;

/**
 * @author lfiandesio
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class TestFAMECommandExecutor extends TestCase {

	public void testExecuteProcedure() {
	}

	public void testGetResults() {
		
		FAMECommandExecutor fce = new FAMECommandExecutor();
		FAMEExecutionResultsTO to =  fce.getResults("100");
		assertNotNull(to);
	}
	
	
}
