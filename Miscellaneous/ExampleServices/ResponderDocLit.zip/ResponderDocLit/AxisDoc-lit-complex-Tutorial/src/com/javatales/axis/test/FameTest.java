/*
 * Created on May 24, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.javatales.axis.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.xml.rpc.ServiceException;

import com.javatales.axis.gen.FameServiceImpl;
import com.javatales.axis.gen.FameServiceImplServiceLocator;
import com.javatales.axis.to.BinaryFileTO;
import com.javatales.axis.to.FAMEArgumentsTO;
import com.javatales.axis.to.FAMEExecutionResultsTO;
import com.javatales.axis.to.FAMEProcedureTO;
import com.javatales.axis.util.IOUtil;

/**
 * @author lfiandesio
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class FameTest {

    private static final String URL = "http://127.0.0.1:8080/axis/services/fameLounge";

    private static final String PATH = "/tmp/";

    public static void main(String[] args) {
        FameTest ft = new FameTest();
        //ft.testExecuteProcedure();
        ft.testReceiveFile(ft.testExecuteProcedure());
    }

    private static String testExecuteProcedure() {

        // Create the object used as a bag for the data
        FAMEArgumentsTO to = new FAMEArgumentsTO();
        // Create the TO used for the main FAME procedure
        FAMEProcedureTO proc = new FAMEProcedureTO();
        byte[] mainprocedure = null;
        try {
            // The procedure file is read from
            // the file system
            mainprocedure = IOUtil.readFile(new File(PATH
                    + "test_files/procedure.txt"));
        } catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        proc.setProcedureName("FAME MAIN TEST 1");
        proc.setFAME4GLCode(new String(mainprocedure));
        // Set the procedure
        to.setMainProcedure(proc);

        DataHandler[] dhs = new DataHandler[5];
        // Create 5 datasets...
        for (int i = 0; i < 5; i++) {
            // Also datasets are read from the file system
            FileDataSource fx = new FileDataSource(PATH
                    + "test_files/testdataset.txt");
            // The main TO expose an array of DataHandler
            DataHandler dh1 = new DataHandler(fx);
            dhs[i] = dh1;
        }
        to.datasets = dhs;
        String res = null;
        try {
            // Invoke the webservice...
            res = getService(URL).executeFameProcedure(to);
            System.err.println("Correlation id: " + res);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }

    private void testReceiveFile(final String corrId) {
        try {
            FAMEExecutionResultsTO to = getService(URL).retrieveResult(corrId);

            if (to != null) {
                IOUtil.createDir(PATH + corrId);
                File f = IOUtil.createDir(PATH + corrId + "/" + "results");
                if (f.exists()) {
                    System.err.println("SUCCESS");
                    if (to.getBinaryFiles() != null) {
                        for (int i = 0; i < to.getBinaryFiles().length; i++) {
                            //System.err.println("SUCCESS"+i);
                            BinaryFileTO bfto = to.getBinaryFiles()[i];
                            IOUtil.writeDataHandler(bfto.getBinaryFile(), f
                                    .getPath()
                                    + "/" + "res" + i);
                        }
                    }

                    if (to.getDatasetFiles() != null) {
                        for (int i = 0; i < to.getDatasetFiles().length; i++) {
                            String dset = to.getDatasetFiles()[i];
                            IOUtil.writeFile(f.getPath() + "/" + "dataset_res_"
                                    + i, dset);
                        }
                    }
                } else {
                    System.err.println("Problem creating dir");

                }

            }
        } catch (RemoteException e) {
            e.printStackTrace();
        }

    }

    private static FameServiceImpl getService(final String endPointUrl) {
        FameServiceImpl result = null;

        try {
            FameServiceImplServiceLocator loc = new FameServiceImplServiceLocator();

            if (endPointUrl != null) {
                URL url = new URL(endPointUrl);
                result = loc.getfameLounge(url);
            } else {
                result = loc.getfameLounge();
            }
        } catch (MalformedURLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (ServiceException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return result;
    }

}