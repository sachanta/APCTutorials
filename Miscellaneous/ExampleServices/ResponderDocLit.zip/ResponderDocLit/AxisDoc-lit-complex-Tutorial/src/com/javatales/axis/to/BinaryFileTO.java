/*
 * Created on 18-feb-2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.javatales.axis.to;

import javax.activation.DataHandler;

/**
 * @author lfiandesio
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class BinaryFileTO {

	private DataHandler binaryFile;
	private String fileName;
	public BinaryFileTO(){
		
	}
	
	
	/**
	 * @param string
	 * @param d
	 */
	public BinaryFileTO(String filename, DataHandler binaryContent) {
		
		this.fileName = filename;
		this.binaryFile = binaryContent;
	}

	/**
	 * @return
	 */
	public DataHandler getBinaryFile() {
		return binaryFile;
	}

	/**
	 * @return
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param handler
	 */
	public void setBinaryFile(DataHandler handler) {
		binaryFile = handler;
	}

	/**
	 * @param string
	 */
	public void setFileName(String string) {
		fileName = string;
	}

}
