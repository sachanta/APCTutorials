/*
 * Created on 8-feb-2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.javatales.axis.to;

import javax.activation.DataHandler;

/**
 * This Transfer Object is used to set the main FAME procedure,
 * the sub procedures and the datasets necessary to run a FAME
 * procedure. 
 * 
 * @author lfiandesio
 *
 */
public class FAMEArgumentsTO {
	/*
	 * Holds the main FAME procedure
	 * to execute
	 */
	private FAMEProcedureTO mainProcedure;
	
	
	/*
	 * Hold an array of datasets.
	 * Left to public visibility
	 * because of a Axis 1.1 bug.
	 */
	public DataHandler[] datasets;

	
	/**
	 * @return
	 */
	public FAMEProcedureTO getMainProcedure() {
		return mainProcedure;
	}

	/**
	 * @param string
	 */
	public void setMainProcedure(FAMEProcedureTO procTO) {
		mainProcedure = procTO;
	}

}
