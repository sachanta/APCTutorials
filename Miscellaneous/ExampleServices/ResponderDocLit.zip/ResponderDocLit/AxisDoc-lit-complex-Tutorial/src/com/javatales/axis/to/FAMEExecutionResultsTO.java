/*
 * Created on 8-feb-2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.javatales.axis.to;

import javax.activation.DataHandler;

/**
 * @author lfiandesio
 * 
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class FAMEExecutionResultsTO {

    private BinaryFileTO[] binaryFiles;

    private String[] asciiFiles;

    private String[] datasetFiles;

    private String correlationId;

    /**
     * @return Returns the correlationId.
     */
    public String getCorrelationId() {
        return correlationId;
    }

    /**
     * @param correlationId
     *            The correlationId to set.
     */
    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    /**
     * @return
     */
    public String[] getAsciiFiles() {
        return asciiFiles;
    }

    /**
     * @return
     */
    public BinaryFileTO[] getBinaryFiles() {
        return binaryFiles;
    }

    /**
     * @return
     */
    public String[] getDatasetFiles() {
        return datasetFiles;
    }

    /**
     * @param strings
     */
    public void setAsciiFiles(String[] strings) {
        asciiFiles = strings;
    }

    /**
     * @param fileTOs
     */
    public void setBinaryFiles(BinaryFileTO[] fileTOs) {
        binaryFiles = fileTOs;
    }

    /**
     * @param strings
     */
    public void setDatasetFiles(String[] strings) {
        datasetFiles = strings;
    }

}