/*
 * Created on 01.11.2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.javatales.axis.to;


/**
 * A FAME procedure descriptor. Describes a fame procedure
 * by providing a name version and the 4GL code.
 *
 * @author makumbi
 * @since MDP Release 1.0
 */
public class FAMEProcedureTO {
	// The name of the procedure
	private String procedureName;

	// The version
	private String procedureVersion;
	
	// date
	private String procedureDate;
	
	// identifier
	private String procedureId;

	// The 4GL source code
	private String FAME4GLCode;
	
	/**
	 * default constructor.
	 */
	public FAMEProcedureTO() {
	}

	/**
	 * Constructs an instance of this procedure
	 * with the specified name and version
	 *
	 * @param name      the name of the procedure
	 * @param version   the version of the procedure
	 */
	public FAMEProcedureTO(String name, String version) {
		this.procedureName = name;
		this.procedureVersion = version;
	}

	/**
	 * REturns the 4GL source code that makes
	 * up the procedure.
	 * 
	 * @return
	 */
	public String getFAME4GLCode() {
		return FAME4GLCode;
	}

	/**
	 * Returns the date related to this procedure
	 * TODO: is this required?
	 *  
	 * @return String the date 
	 */
	public String getProcedureDate() {
		return procedureDate;
	}

	/**
	 * Returns the unique identifier for 
	 * this procedure
	 * 
	 * @return the identifier
	 */
	public String getProcedureId() {
		return procedureId;
	}

	/**
	 * Returns the name of the procedure
	 *
	 *
	 * @return  String the name of the procedure
	 */
	public String getProcedureName() {
		return procedureName;
	}

	/**
	 * Returns a string that identifies the version
	 * of this procedure
	 * 
	 * @return String the procedure version
	 */
	public String getProcedureVersion() {
		return procedureVersion;
	}

	/**
	 * Sets the 4GL source code for this procedure
	 *
	 * @return  String the 4GL source code
	 */
	public void setFAME4GLCode(String string) {
		FAME4GLCode = string;
	}

	/**
	 * Sets a date to define this procedure
	 * TODO: is this required?
	 * 
	 * @param string
	 */
	public void setProcedureDate(String string) {
		procedureDate = string;
	}

	/**
	 * Sets the procedure identifier
	 * 
	 * @param string
	 */
	public void setProcedureId(String string) {
		procedureId = string;
	}

	/**
	 * Sets the name of the procedure
	 *
	 * @param  procedureName the name of the procedure
	 */
	public void setProcedureName(String string) {
		procedureName = string;
	}

	/**
	 * Sets the version of the procedure
	 *
	 * @param  procedureVersion the version to set
	 */
	public void setProcedureVersion(String procedureVersion) {
		this.procedureVersion = procedureVersion;
	}

}
