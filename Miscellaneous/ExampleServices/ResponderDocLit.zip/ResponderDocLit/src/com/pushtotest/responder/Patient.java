package com.pushtotest.responder;

public class Patient {

    private int id = 0;
    private String name = "Frank";
    private String address = "2248 Montezuma Drive";
    
    /** Creates a new instance of Patient */
    public Patient() 
    {
    }

    /*
     * <pre>
     * <patient id="483">
     *     <name>Frank Cohen</name>
     *     <address>2248 Montezuma Drive</address>
     *     <city>Campbell</city>
     *     <state>CA</state>
     *     <medicalevent>
     *         <hospitalstay>
     *             <name>Mount Sanai Hospital</name>
     *             <date>May 17, 2005</date>
     *             <treatment>Shoulder injury</treatment>
     *         </hospitalstay>
     *     </medicalevent>
     *     <medicalevent>
     *         <hospitalstay>
     *             <name>Vail Mountain Hospital</name>
     *             <date>May 25, 2005</date>
     *             <treatment>Wrist sprain</treatment>
     *         </hospitalstay>
     *     </medicalevent>
     * </patient>
     * </pre> 
     */
    
}
