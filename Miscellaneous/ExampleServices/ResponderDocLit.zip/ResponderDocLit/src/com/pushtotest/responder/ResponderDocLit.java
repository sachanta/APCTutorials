package com.pushtotest.responder;

/*
Responder implements a Web Service using Document-literal encoding and
complex data types. Responder is hosted on examples.pushtotest.com to
support a sample test agent that comes with TestMaker, the Web Service
test for functionality, scalability, and reliability.

For more info check http://www.pushtotest.com or send email to info@pushtotest.com

This program is free software; you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
PARTICULAR PURPOSE. See the GNU General Public License for more details

TestMaker comes with a copy of the GNU General Public License in the docs/license.html file;
if you cannot find the license, then write to the Free Software Foundation, Inc., 59 Temple 
Place - Suite 330, Boston, MA 02111-1307, USA.

Please direct questions regarding this license agreement to PushToTest at 
2248 Montezuma Drive, Campbell, California 95008 USA, phone: (408) 374-7426.
*/

import org.w3c.dom.Element;

/**
 * ResponderDocLitComplex interface definition. This interface is used as
 * as input to the Java2WSDL utility in Apache Axis to publish a Web Service
 * using Document-literal encoding and complex data types.
 *
 * @author Frank Cohen (fcohen at pushtotest.com)
 */

public class ResponderDocLit
{

    /*
     * Patient record following this schema:
     * <patient id="483">
     *     <name>Frank Cohen</name>
     *     <address>2248 Montezuma Drive</address>
     *     <city>Campbell</city>
     *     <state>CA</state>
     *     <medicalevent>
     *         <hospitalstay>
     *             <name>Mount Sanai Hospital</name>
     *             <date>May 17, 2005</date>
     *             <treatment>Shoulder injury</treatment>
     *         </hospitalstay>
     *     </medicalevent>
     *     <medicalevent>
     *         <hospitalstay>
     *             <name>Vail Mountain Hospital</name>
     *             <date>May 25, 2005</date>
     *             <treatment>Wrist sprain</treatment>
     *         </hospitalstay>
     *     </medicalevent>
     * </patient>
     */
    
    /** Creates a new instance of ResponderDocLit */
    public ResponderDocLit() {
    }
    
    public int enterPatient( Patient mypatient )
    {
        return 0;        
    }
    
    public Patient getPatientRecord( int patientid )
    {
        return null;
    }
        
}
