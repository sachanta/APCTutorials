/*
 * $Id: Lingo.java,v 1.1.1.1 2006/09/25 23:40:55 fcohen Exp $
 * Title:        Lingo
 * Version:      2.0
 * Copyright:    (c) 2001 PushToTest. All rights reserved.
 *  
 * For more info check: www.pushtotest.com
 * 
 * This source code is licensed under terms described in the License.txt file.
*/

package com.pushtotest.responder;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.Random;

/**
 * Lingo creates dummy text for message body and message subject.
 * The 2 methods that do the real work are the getMessage and getSubject that
 * take the 4 arguments, the rest of the methods just pass in some default values
 * for that stuff. It creates strings of pseudo-randomly selected words.
 * @author Geoff Lane <a href="mailto:glane@pushtotest.com"><glane@pushtotest.com></a>
 */
public class Lingo {

    private final static String[] kCaps = { "Lipsem", "Delorum", "Campus", "Novato",
                                            "Biscort", "Aquam", "Betsy", "Via" };
    private final static String[] kTokens = { "ipsem","delorum", "sit", "novus", "deplorem",
                                            "ventes", "surbatton", "it", "maddy", "quantos", "infreteres",
                                            "so", "ditchek", "jack", "aqua", "ad" };

    private Random myRandom;
    private String[] caps;
    private String[] tokens;

    /**
     * Default constructor.
     * Uses the default list of fake Latin words.
     */
    public Lingo() {
        myRandom = new Random( new Date().getTime() );
        caps = kCaps;
        tokens = kTokens;
    } // Lingo


    /**
     * Creates a Lingo object allowing the user to set the Capital words and
     * the lowercase tokens that they would like to use to generate the Lingo.
     * @param inCaps The capital words used for starting sentences.
     * @param inTokens The lowercase words used for everything else
     */
    public Lingo(String[] inCaps, String[] inTokens) {
        myRandom = new Random(new Date().getTime());

        if (inCaps != null && inCaps.length != 0)
            caps = inCaps;
        else
            caps = kCaps;

        if (inTokens != null && inTokens.length != 0)
            tokens = inTokens;
        else
            tokens = kTokens;
    } // Lingo


    /**
     * Creates a Lingo Message with a default size of about 35 words.
     * This method uses capital letters, periods, etc.
     * @return The Lingo Message
     */
    public String getMessage() {
        return getMessage(((Math.abs(myRandom.nextInt()) % 70) + 35), true, true, false);
    } // getMessage


    /**
     * Creates a Lingo Message of the length specified
     * This method uses capital letters, periods, etc.
     * @param length The length that you want the message
     * @return The Lingo Message
     */
    public String getMessage(int length) {
        return getMessage(((Math.abs( myRandom.nextInt()) % (length*2)) + length), true, true, false);
    } // getMessage


    /**
     * Creates a Lingo message with a default size of 35 words.
     * This method uses capital letters, periods, etc.
     * @return A URLEncoded version of the Lingo string
     */
    public String getMessageEncoded() {
        return getMessage(((Math.abs(myRandom.nextInt()) % 70) + 35), true, true, true);
    } // getMessageEncoded


    /**
     * Creates a Lingo Message of the length specified
     * This method uses capital letters, periods, etc.
     * @param length The length that you want the message
     * @return The Lingo Message
     */
    public String getMessageEncoded( int length ) {
        return getMessage(((Math.abs(myRandom.nextInt()) % (length*2)) + length), true, true, true);
    } // getMessage


    /**
     * Assemble the new subject line
     * Uses a default of about 3 words
     * @return The Lingo String
     */
    public String getSubject() {
        return getSubject(((Math.abs(myRandom.nextInt()) % 6) + 3), true, false, false);
    } // getSubject


    /**
     * Assemble the new subject line
     * Uses a default of about 3 words
     * @param length The length that you want the message
     * @return The Lingo String
     */
    public String getSubject(int length) {
        return getSubject(((Math.abs(myRandom.nextInt()) % (length*2) ) + length), true, false, false);
    } // getSubject


    /**
     * Assemble the new subject line
     * Uses a default of about 3 words
     * @return The URLEncoded version of the Lingo string
     */
    public String getSubjectEncoded() {
        return getSubject(((Math.abs( myRandom.nextInt()) % 6) + 3), true, false, true);
    } // getSubjectEncoded


    /**
     * Assemble the new subject line
     * @param length The length that you want the message
     * @return The URLEncoded version of the Lingo string
     */
    public String getSubjectEncoded( int length ) {
        return getSubject( ( ( Math.abs( myRandom.nextInt() ) % (length*2) ) + length ), true, false, true );
    } // getSubjectEncoded


    /**
     * Assemble the new message body.
     * This method uses capital letters, periods, newlines etc.
     * @param size The length you want the message to be
     * @param startCap Start with a capital letter?
     * @param endPeriod End with a period?
     * @param encoded URL Encoded?
     * @return The Lingo string for a body
     */
    public String getMessage( int size, boolean startCap, boolean endPeriod, boolean encoded ) {
        if (size <= 0)
            size = 35;
        StringBuffer myBody = new StringBuffer();

        for (int i = 0; i < size; i++ ) {
            // If this is the first loop and we want to
            if (i == 0 && startCap) {
                // This is the first loop, start with a capital
                myBody.append(caps[Math.abs(myRandom.nextInt()) % caps.length]);

            } else if (i == size-1 && endPeriod) {
                // End of the loop, tack on a period if requested
                myBody.append(".");

            } else {
                // Regular loop, look to see if we should start a new sentence
                int rand = Math.abs(myRandom.nextInt()) % 20;
                if (rand < 3) {
                    // mix it up some and throw in some newlines
                    if (rand == 1) {
                        myBody.append(".\n\n").append(caps[Math.abs(myRandom.nextInt()) % caps.length]);
                    } else {
                        myBody.append(". ").append(caps[ Math.abs(myRandom.nextInt()) % caps.length]);
                    }

                } else {
                    // otherwise just get a regular word and space
                    myBody.append(" ");
                    myBody.append(tokens[Math.abs(myRandom.nextInt()) % tokens.length]);

                }
            }
        }

        // Should we URL encode this string?
        if (encoded) {
            String val = myBody.toString();
            try {
                val = URLEncoder.encode(val, "UTF-8");
            } catch(UnsupportedEncodingException ex) {
            }
            return val;
        } else
            return myBody.toString();
    } // newLingoMessage


    /**
     * Builds a Lingo String suitable for the subject of a message
     * It won't have line breaks or anything in it
     * @param size The length you want the message to be
     * @param startCap Start with a capital letter?
     * @param endPeriod End with a period?
     * @param encoded URL Encoded?
     * @return The Subject string
     */
    public String getSubject(int size, boolean startCap, boolean endPeriod, boolean encoded) {
        if(size <= 0)
            size = 35;
        StringBuffer myBody = new StringBuffer();

        for (int i = 0; i < size; i++) {
            // If this is the first loop and we want to
            if (i == 0 && startCap) {
                // This is the first loop, start with a capital
                myBody.append(caps[ Math.abs(myRandom.nextInt()) % caps.length]);

            } else if( i == size-1 && endPeriod ) {
                // End of the loop, tack on a period if requested
                myBody.append(".");

            } else {
                // otherwise just get a regular word and space
                myBody.append(" ");
                myBody.append(tokens[Math.abs(myRandom.nextInt()) % tokens.length]);

            }
        }

        // Should we URL encode this string?
        if (encoded) {
            String val = myBody.toString();
            try {
                val = URLEncoder.encode(val, "UTF-8");
            } catch(UnsupportedEncodingException ex) {
            }
            return val;
        } else
            return myBody.toString();
    } // getSubject


    /**
     * Return just a single Lingo word
     * @return A single pseudo random word.
     */
    public String getSingle() {
        return tokens[Math.abs(myRandom.nextInt()) % tokens.length];
    } // newLingo

} // Lingo

