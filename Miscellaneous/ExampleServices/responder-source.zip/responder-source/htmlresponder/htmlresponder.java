/** Responder - implements a server-side utility for testing Web Services
 *
 * @author Frank Cohen (mailto:fcohen@pushtotest.com)
 * @version 3.0
 * @copyright (c) 2002 Frank Cohen. All rights reserved.
 * @company http://www.PushToTest.com
 *
 * For more info check http://www.pushtotest.com or send email to info@pushtotest.com
 * This source code is licensed under terms described in the License.txt file.
 *
 */

package com.pushtotest.responder;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import javax.servlet.ServletContext;
import javax.servlet.ServletConfig;
import javax.servlet.http.HttpServletResponse;

import java.util.Date;
import java.lang.StringBuffer;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.InputStream;

import java.util.Enumeration;
import java.util.Properties;
import javax.servlet.http.Cookie;
import javax.servlet.ServletException;

import java.util.Date;
import java.util.Random;

public class htmlresponder extends HttpServlet {
    
    private static Properties props = null;
    private static Lingo mylingo = null;
    private Random myRandom;
        
    private static final String filelocation = "/WEB-INF/classes/com/pushtotest/responder/resources/";
    
    /** Initializes the servlet.
     */
    public void init(ServletConfig config) throws ServletException {
        super.init(config);

        myRandom = new Random( new Date().getTime() );

        // Lingo is a handy utility for creating English-like sample text
        mylingo = new Lingo();

        // Open the Properties file
        props = new Properties();
        try
        {
            props.load( getServletContext().getResourceAsStream( filelocation + "messages.properties" ));
        }
        catch ( IOException ioex )
        {
            System.out.println("Error opening messages.properties: " + ioex );
        }
    }
    
    /** Destroys the servlet.
     */
    public void destroy() {
        
    }
    
    /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     */
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response, boolean postFlag )
    throws ServletException, java.io.IOException 
    {
        java.io.PrintWriter out = response.getWriter();
        
        String xmlparam = request.getParameter("xml");
        if ( xmlparam != null )
        {
            response.setContentType("xml/html");
            out.println("<?xml version=\"1.0\" encoding=\"utf-8\"?>" );
            out.println("<invoices>");
            out.println("  <products>" + Math.abs(myRandom.nextInt()) % 70 + "</products>");
            out.println("  <services>" + Math.abs(myRandom.nextInt()) % 30 + "</services>");
            out.println("  <returns>" + Math.abs(myRandom.nextInt()) % 20 + "</returns>");
            out.println("  <boards-sold>" + Math.abs(myRandom.nextInt()) % 10 + "</boards-sold>");
            out.println("</invoices>");
            out.close();
            return;
        }
               
        response.setContentType("text/html");
        
        String parm = "";

        // Handle cookies

        String cookie = request.getParameter("cookie");
        String cookieval = request.getParameter("cookievalue");

        if ( cookie == null )
        {
            // There was no cookie parameter sent so replay the existing cookies
            Cookie theCookies [] = request.getCookies();

            if ( theCookies != null )
            {
                for ( int i = 0; i < theCookies.length; i++ )
                {
                    response.addCookie( theCookies[ i ] );
                }
            }
        }
        else
        {
            // We got a cookie parameter so send it back in the response
            Cookie myCookie = new Cookie( cookie, cookieval );
            response.addCookie( myCookie );
        }
        
        // Handle redirect

        String redirect = request.getParameter("redirect");
        if ( redirect != null )
        {
            response.sendRedirect( response.encodeRedirectURL( redirect ) );
        }
        
        
        // Handle bomb

        parm = request.getParameter("bomb");
        long bomb = (parm != null) ? Integer.parseInt(parm) : 0;

        if ( bomb > 0 )
        {
            snooze( bomb );
            throw new ServletException("Responder commanded to bomb");
        }
         
        // Handle timeout

        parm = request.getParameter("timeout");
        long timeout = (parm != null) ? Integer.parseInt(parm) : 0;

        if ( timeout > 0 )
        {
            snooze( timeout );
            out.close();
        }
        
        // Handle file parameter
        
        parm = request.getParameter("file");
        String thefile = (parm != null) ? parm : "file1.html";
        thefile = filelocation + thefile;

        // Handle lingosize

        parm = request.getParameter("lingosize");
        int lingosize = (parm != null) ? Integer.parseInt(parm) : 0;
        
        if ( lingosize > 0 )
        {
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Responder - the best in Web Service testing from http://www.PushToTest.com</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("This is the responder here. I am from <a href=http://www.PushToTest.com>http://www.PushToTest.com</a>. I have something to say . . . <br><br>");

            out.println( mylingo.getMessage( lingosize, true, true, false ) );

            out.println("</body>");
            out.println("</html>");
            out.flush();
        }
        else
        {
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Responder - the best in Web Service testing from http://www.PushToTest.com</title>");
            out.println("</head>");
            out.println("<body>");
            
            // If this was the result of an HTTP Post/Form Submit then
            // send back the values we received.
            if ( postFlag )
            {
                out.println("PushToTest Responder was called using a HTTP Post command. Here are the values received:<br>");

                Enumeration e = request.getParameterNames();
                String f = "";
                while ( e.hasMoreElements() )
                {
                    f = (String) e.nextElement();
                    out.println( f + "=" + request.getParameter( f ) + "<br>" );
                }
                out.println("Now back to the show . . .<br><br>");
            }
            
            out.println( getFileParsed( thefile ) );

            out.println("</body>");
            out.println("</html>");
            out.flush();
        }

        // Handle sleeptime
        
        parm = request.getParameter("sleeptime");
        long sleeptime = (parm != null) ? Integer.parseInt(parm) : 0;

        if ( sleeptime > 0 )
        {
            snooze( sleeptime );
        }
        
        out.close();
    }
    
    /** Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processRequest(request, response, false);
    }
    
    /** Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processRequest(request, response, true);
    }
    
    /** Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return getAProperty( "about" );
    }

    /** Returns the contents of a file (unparsed) from com.pushtotest.responder.resources
     * If the file is not found then this returns an html page saying "file not found"
     *
     * @param String filename
     */
   
   private String getFile( String thefile )
   {
       
        StringBuffer contents = new StringBuffer();

        String line = "";

        InputStream in = getServletContext().getResourceAsStream( thefile );
        
        if ( in == null )
        {
            return "<html><body>File not found: " + thefile + "</body></html>";
        }
        
        BufferedReader br =  new BufferedReader( new InputStreamReader( in ) ); 

        try
        {
            while ( ( line = br.readLine() ) != null )
            {
                contents.append( line );
            }
        }
        catch ( IOException ioex )
        {
            return "Exception: " + ioex;
        }
        
        return contents.toString();
   }

   /** Get a file and parse-and-replace $$ commands. For example,
    * $lingo$ anywhere in the file will be replaced with a random word
    * $time$ is replaced with the current time in milliseconds since Jan 1, 1970
    * $filename$ is replaced with the parsed contents of the filename given.
    * 
    * @param String thefilename
    * @return String the parsed contents
    */
   
    private String getFileParsed( String thefile )
    {
        boolean pd = false;
        
        String a = getFile( thefile );
       
        int mark = 0;
        int end = 0;
        String preamble = "";
        String command = "";

        while ( a.indexOf("$") > -1 )
        {
            mark = a.indexOf("$");

            preamble = a.substring( 0, mark );

            a = a.substring( mark + 1 );

            end = a.indexOf( "$" );

            command = a.substring( 0, end );

            a = a.substring( end + 1 );

            if ( command.equals("lingo") )
            {
                String b = mylingo.getMessage( 250, true, true, false );
                a = preamble + b + a;
                pd = true;
            }

            if ( command.equals("time") )
            {
                Date myDate = new Date();
                a = preamble + myDate.getTime() + a;
                pd = true;
            }

            // By default try to get the file name of the command
            if ( ! command.equals("") && !pd )
            {
                a = preamble + getFileParsed( filelocation + command ) + a;
            }
            
            
        }
        
        return a;
   }

    /** Snooze is a simple utility method that causes this thread to sleep
     *@param long milliseconds to sleep
     */
    
    private void snooze( long thesecs )
    {
        try
        {
            Thread.sleep( thesecs );
        }
        catch ( Exception e )
        {
            System.err.println("htmlresponder: Exception on sleep.");
        }
    }

    /** Utility method to read from the message.properties file
     */
    private String getAProperty( String thekey )
    {
        return props.getProperty( thekey );
    }
    
}
